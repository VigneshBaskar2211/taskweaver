from typing import Literal

RoleName = Literal["User", "Planner", "CodeInterpreter", "Unknown"]
RoundState = Literal["finished", "failed", "created"]
