from .cli import __main__


def main():
    __main__.main()


if __name__ == "__main__":
    main()
